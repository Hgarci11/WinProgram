# 해야할 일

입력을 받아 대문자로 바꿔 출력하는 함수를 작성하세요.

## 인자

* input: 임의의 영단어 문자열(lorem ipsum).

## 템플릿

```js
function upperCaser(input) {
  // 여기에 해답을 적으세요
}

module.exports = upperCaser
```
