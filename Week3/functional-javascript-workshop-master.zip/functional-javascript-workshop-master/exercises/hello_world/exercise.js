"use strict"

var runner = require('../runner')

module.exports = runner(require('lorem-ipsum')())
